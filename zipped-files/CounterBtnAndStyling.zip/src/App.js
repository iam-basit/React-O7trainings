import React from 'react'
import './App.css'
import CounterBtn from './CounterBtn'

function App() {
  return (
    <>
      <CounterBtn />
    </>
  )
}

export default App
