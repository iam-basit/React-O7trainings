export default function useStateHook() {
  let [name, setName] = useState('')

  return (
    <>
      <form>
        <label>Name</label>
        <input type="text" onChange={} />
      </form>
    </>
  )
}
