import './App.css'
import React, { Fragment } from 'react'

function App() {
  // Define cell styles
  const cellStyles = {
    border: '1px solid blue',
    padding: '8px',

    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  }
  var songs = [
    { singer_name: 'taylor swift', song_name: 'the man', type: 'pop' },
    { singer_name: 'sza', song_name: 'kill bill', type: 'filmi' },
    { singer_name: 'diljit', song_name: 'hass hass', type: 'punjabi' },
  ]
  const singerNames = songs.map((singerObj) => singerObj.singer_name)
  const songNames = songs.map((singerObj) => singerObj.song_name)
  const types = songs.map((singerObj) => singerObj.type)

  return (
    <Fragment>
      <div style={cellStyles}>
        <div>
          Singer Names:
          {singerNames.map((singer_name, index) => (
            <p style={cellStyles} key={index}>
              {index}: {singer_name}
            </p>
          ))}
        </div>
        <div>
          Song Names:
          {songNames.map((song_name, index) => (
            <p style={cellStyles} key={index}>
              {index}: {song_name}
            </p>
          ))}
        </div>
        <div>
          Type:
          {types.map((type, index) => (
            <p style={cellStyles} key={index}>
              {index}: {type}
            </p>
          ))}
        </div>
      </div>
    </Fragment>
  )
}

export default App
