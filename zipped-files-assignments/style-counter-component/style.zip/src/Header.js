export default function Header(){
    return(
        <div>
        <h1>This is header</h1>
        <p>para1</p>
        <h1>Headin2</h1>
        </div>
    )
}
// export default Header