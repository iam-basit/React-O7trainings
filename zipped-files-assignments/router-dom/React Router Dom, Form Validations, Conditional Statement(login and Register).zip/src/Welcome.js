export default function Welcome(){
    return(
        <>
            <h1>Welcome User</h1>
        </>
    )
}